import java.awt.*;
import java.util.*;

public class SandGame
{
    public static void main(String[] args)
    {
        SandGame game = new SandGame(120, 80);
        game.run();
    }

    //add constants for particle types here
    public static final int EMPTY = 0;
    public static final int METAL = 1;
    public static final int SAND = 2;
    public static final int WATER = 3;
    public static final int ACID = 4;
    public static final int FIREWORK = 5;
    public static final int SNOW = 6;
    public static final int FOG = 7;
    public static final int STEAM = 8;
    public static final int CONFETTI = 9;
    public static final int RAIN = 10;
    public static final int BLIZZARD = 11;
    public static final int ACIDRAIN = 12;
    public static final int SANDSTORM = 13;
    public static final int LASER= 14;
    public static final int PARTY= 15;
    public static final int SKY= 16;
    //do not add any more fields
    private int[][] grid;
    private SandDisplay display;
    private Color g;
    private boolean skyss;

    public SandGame(int numRows, int numCols)
    {
        String[] names;
        names = new String[17];
        names[EMPTY] = "Empty";
        names[METAL] = "Metal";
        names[SAND] = "Sand";
        names[WATER] = "Water";
        names[ACID] = "Acid";
        names[FIREWORK] = "Firework";
        names[SNOW] = "Snow";
        names[FOG] = "Fog";
        names[STEAM] = "Steam";
        names[CONFETTI] = "Confetti";
        names[RAIN] = "Rain";
        names[BLIZZARD] = "Blizzard";
        names[ACIDRAIN] = "Acid Rain";
        names[SANDSTORM] = "Sandstorm";
        names[LASER] = "Laser";
        names[PARTY] = "Party";
        names[SKY] = "Mr. Blue Sky";
        display = new SandDisplay("Falling Sand", numRows, numCols, names);
        grid= new int[numRows][numCols];
    }

    //called when the user clicks on a location using the given tool
    private void locationClicked(int row, int col, int tool)
    {
        grid[row][col]=tool;
    }

    //copies each element of grid into the display
    public void updateDisplay()
    {
        for(int x=0; x<grid.length;x++){
            for(int y=0; y<grid[0].length;y++){
                if(grid[x][y] == EMPTY && skyss==false){
                    Color g=new Color(0,0,0);
                    display.setColor(x,y,g );
                }
                else if(grid[x][y] == SAND){
                    display.setColor(x,y, new Color(239,221,111)); 
                }
                else if(grid[x][y] == WATER){
                    display.setColor(x,y, new Color(28,163,236)); 
                }
                else if(grid[x][y] == ACID){
                    display.setColor(x,y, new Color(143,254,9)); 
                }
                else if(grid[x][y] == FIREWORK){
                    int r=(int)(Math.random()*255);   
                    display.setColor(x,y, new Color(255,r/2,(int)r/3)); 
                }
                else if(grid[x][y] == SNOW){  
                    display.setColor(x,y, new Color(245,245,255)); 
                }
                else if(grid[x][y] == FOG){  
                    display.setColor(x,y, new Color(225,235,255)); 
                }
                else if(grid[x][y] == STEAM){  
                    display.setColor(x,y, new Color(235,235,255)); 
                }
                else if(grid[x][y] == CONFETTI){
                    int r=(int)(Math.random()*255);   
                    int c=(int)(Math.random()*255); 
                    int n=(int)(Math.random()*255); 
                    display.setColor(x,y, new Color(r,c,n)); 
                }
                else if(grid[x][y] == LASER){
                    display.setColor(x,y, new Color(225,20,20)); 
                }
                else  if(grid[x][y] == EMPTY && skyss==true){
                    Color a=new Color(135,206,235);
                    display.setColor(x,y,a );
                }

                else {
                    display.setColor(x,y, new Color(114,114,114));
                }
            }
        }
    }

    //called repeatedly.
    //causes one random particle to maybe do something.
    public void step()
    {
        int x= (int)(Math.random()*grid.length);
        int y= (int)(Math.random()*grid[0].length);

        if(grid[x][y]==SAND && x+1<grid.length &&  grid[x+1][y]==EMPTY){
            grid[x][y]=EMPTY;
            grid[x+1][y]=SAND;
        }
        else if(grid[x][y]==WATER ){
            int r=(int)(Math.random()*3);   
            if(r==0){
                if(y+1<grid[0].length && grid[x][y+1]==EMPTY)
                {grid[x][y]=EMPTY;
                    grid[x][y+1]=WATER;

                }
            }
            else if(r==1){
                if(y>0 && grid[x][y-1]==EMPTY)
                {grid[x][y]=EMPTY;
                    grid[x][y-1]=WATER;
                }

            }
            else{
                if(x+1<grid.length &&grid[x+1][y]==EMPTY)
                {grid[x][y]=EMPTY;
                    grid[x+1][y]=WATER; 
                }

            }
        }
        else if(grid[x][y]==SAND && x+1<grid.length &&  grid[x+1][y]==WATER){
            grid[x][y]=WATER;
            grid[x+1][y]=SAND;
        }
        else if(grid[x][y]==ACID ){
            int r=(int)(Math.random()*3);   
            if(r==0){
                if(y+1<grid[0].length && grid[x][y+1]!=WATER )
                {grid[x][y]=EMPTY;
                    grid[x][y+1]=ACID;

                }
                else if(y+1<grid[0].length && grid[x][y+1]==WATER ){
                    grid[x][y]=EMPTY;
                    grid[x][y]=STEAM;
                }
                else {
                    grid[x][y]=EMPTY;
                }
            }
            else if(r==1){
                if(y>0&&grid[x][y-1]!=WATER)
                {grid[x][y]=EMPTY;
                    grid[x][y-1]=ACID;
                }
                else if(y>0&&grid[x][y-1]==WATER ){
                    grid[x][y]=EMPTY;
                    grid[x][y]=STEAM;
                }
                else {
                    grid[x][y]=EMPTY;
                }
            }
            else if(r==2){
                if(x+1<grid.length&&grid[x+1][y]!=WATER)
                {grid[x][y]=EMPTY;
                    grid[x+1][y]=ACID; 
                }
                else if(x+1<grid.length&&grid[x+1][y]==WATER){
                    grid[x][y]=EMPTY; 
                    grid[x][y]=STEAM;
                }
                else {
                    grid[x][y]=EMPTY;
                }
            }

        }
        else if((grid[x][y]==SNOW )){
            if(x+1<grid.length &&grid[x+1][y]==EMPTY)
            {grid[x][y]=EMPTY;
                grid[x+1][y]=SNOW; 
            }
            else  if(x+1<grid.length &&grid[x+1][y]==WATER){
                grid[x+1][y]=SNOW;
                grid[x][y]=WATER;
            }
        }
        else if((grid[x][y]==FOG )){
            int c=(int)(Math.random()*3);   
            if(c==0){
                if(y+1<grid[0].length && grid[x][y+1]==EMPTY)
                {grid[x][y]=EMPTY;
                    grid[x][y+1]=FOG;

                }

            }
            else if(c==1){
                if(y>0  && grid[x][y-1]==EMPTY)
                {grid[x][y]=EMPTY;
                    grid[x][y-1]=FOG;
                }
            }
            else if(c==2){
                if(x-1>0  && grid[x-1][y]==EMPTY)
                {grid[x][y]=EMPTY;
                    grid[x-1][y]=FOG; 
                }

            }

            if(x-1>=0 &&grid[x-1][y]==EMPTY)
            {grid[x][y]=EMPTY;
                grid[x-1][y]=FOG; 
            }
            if(x==0){
                grid[x][y]=EMPTY;
            }
        }

    
        else if((grid[x][y]==FIREWORK )){
            int[] mouseLoc = display.getMouseLocation();
            int n= 0;
            int p= 0;
            int a=0; 
            if (mouseLoc != null) { 
                locationClicked(mouseLoc[0], mouseLoc[1], display.getTool());
                n= mouseLoc[0];
                p= mouseLoc[1];
                a=2; 
            }

            if(x+a<grid.length && x-a>=0 && y+a<grid[0].length && y-a>=0
            && x>n-10&& x<n+10 && y>p-9&& y<p+9){

                grid[x][y]=EMPTY;
                grid[x][y-a]=FIREWORK;
                grid[x][y+a]=FIREWORK;
                grid[x-a][y]=FIREWORK;
                grid[x][y]=EMPTY;
                grid[x+a][y]=FIREWORK;    
                a=a+2;

            }
            
            int r=(int)(Math.random()*3);   
            if(r==0){
                if(y+1<grid[0].length && grid[x][y+1]==EMPTY)
                {grid[x][y]=EMPTY;
                    grid[x][y+1]=FIREWORK;

                }
                else

                {
                    grid[x][y]=EMPTY;   
                }
            }
            else if(r==1){
                if(y>0 && grid[x][y-1]==EMPTY)
                {grid[x][y]=EMPTY;
                    grid[x][y-1]=FIREWORK;
                }
                else

                {
                    grid[x][y]=EMPTY;   
                }
            }
            else{
                if(x+1<grid.length &&grid[x+1][y]==EMPTY)
                {grid[x][y]=EMPTY;
                    grid[x+1][y]=FIREWORK; 
                }
                else

                {
                    grid[x][y]=EMPTY;   
                }
            }

        }
        else if((grid[x][y]==STEAM )){
            int c=(int)(Math.random()*3);   
            if(c==0){
                if(y+1<grid[0].length && grid[x][y+1]==EMPTY)
                {grid[x][y]=EMPTY;
                    grid[x][y+1]=STEAM;

                }

            }
            else if(c==1){
                if(y>0  && grid[x][y-1]==EMPTY)
                {grid[x][y]=EMPTY;
                    grid[x][y-1]=STEAM;
                }
            }
            else if(c==2){
                if(x-1>=0  && grid[x-1][y]==EMPTY)
                {grid[x][y]=EMPTY;
                    grid[x-1][y]=STEAM; 
                }

            }

            if(x==0){
                grid[x][y]=EMPTY;
            }
        }
        else if(grid[x][y]==CONFETTI){
            int r=(int)(Math.random()*3);   
            if(r==0){
                if(y+1<grid[0].length && grid[x][y+1]==EMPTY )
                {grid[x][y]=EMPTY;
                    grid[x][y+1]=CONFETTI;

                }
                else{
                    grid[x][y]=EMPTY;
                }
            }
            else if(r==1){
                if(y>0&&grid[x][y-1]==EMPTY)
                {grid[x][y]=EMPTY;
                    grid[x][y-1]=CONFETTI;
                }
                else{
                    grid[x][y]=EMPTY;
                }
            }
            else if(r==2){
                if(x+1<grid.length&&grid[x+1][y]==EMPTY)
                {grid[x][y]=EMPTY;
                    grid[x+1][y]=CONFETTI; 
                }
                else{
                    grid[x][y]=EMPTY;
                }
            }

        }
        else if(grid[x][y] == RAIN){
            int r=(int)(Math.random()* grid[0].length); 
            grid[x][y]= EMPTY;
            grid[0][r]= WATER;
            if(grid[x][y]==WATER && x+1<grid.length &&  grid[x+1][y]==EMPTY){
                grid[x][y]=EMPTY;
                grid[x+1][y]=WATER;
            }
        }
        else if(grid[x][y] == BLIZZARD){
            int r=(int)(Math.random()* grid[0].length); 
            grid[x][y]= EMPTY;
            grid[0][r]= SNOW;
            if(grid[x][y]==SNOW && x+1<grid.length &&  grid[x+1][y]==EMPTY){
                grid[x][y]=EMPTY;
                grid[x+1][y]=SNOW;
            }

        }
        else if(grid[x][y] == ACIDRAIN){
            int r=(int)(Math.random()* grid[0].length); 
            grid[x][y]= EMPTY;
            grid[0][r]= ACID;
            if(grid[x][y]==ACID && x+1<grid.length &&  grid[x+1][y]==EMPTY){
                grid[x][y]=EMPTY;
                grid[x+1][y]=ACID;
            }
            if(x<=0||y<=0){
                grid[x][y]=EMPTY;
            }
        }
        else if(grid[x][y] == SANDSTORM){
            int r=(int)(Math.random()* grid[0].length); 
            grid[x][y]= EMPTY;
            grid[0][r]= SAND;
            if(grid[x][y]==SAND && x+1<grid.length &&  grid[x+1][y]==EMPTY){
                grid[x][y]=EMPTY;
                grid[x+1][y]=SAND;
            }

        }
        else if(grid[x][y] == LASER){
            if( y+1<grid[0].length && grid[x][y+1]!=WATER){
                grid[x][y]=EMPTY;
                grid[x][y+1]=LASER;
            }
            else if(y==grid[0].length && grid[x][y+1]==WATER){
                grid[x][y]=WATER;
            }
            else{
                grid[x][y]=EMPTY;
            }

        }
        else if(grid[x][y] == PARTY){

            grid[x][y]=EMPTY;
            int r= (int)(Math.random()*grid[0].length);
            int q= (int)(Math.random()*grid.length);
            grid[0][r]=CONFETTI;

            if(grid[x][y]==CONFETTI&& x+1<grid.length &&  grid[x+1][y]==EMPTY){
                grid[x][y]=EMPTY;
                grid[x+1][y]=CONFETTI;
            }
            grid[x][y]= FIREWORK;
            grid[q][r]=LASER;
            grid[q][r]=LASER;
            grid[x][y]=EMPTY;
            grid[x][y]=FIREWORK;

        }
        else if(grid[x][y] == SKY){
            grid[x][y]= EMPTY;
            skyss=true;

 
        }
    }

    //do not modify
    public void run()
    {
        while (true)
        {
            for (int i = 0; i < display.getSpeed(); i++)
                step();
            updateDisplay();
            display.repaint();
            display.pause(1);  //wait for redrawing and for mouse
            int[] mouseLoc = display.getMouseLocation();
            if (mouseLoc != null)  //test if mouse clicked
                locationClicked(mouseLoc[0], mouseLoc[1], display.getTool());
        }
    }
}
