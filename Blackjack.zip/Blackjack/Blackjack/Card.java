public class Card
{
    // instance variables - replace the example below with your own
    private int rank;
    private String suit;  
    
    //private boolean isShown;
    public Card(String s, int r)
    {
       rank=r;
       suit=s;
       

    }
    public Card(String s)
    {
        System.out.println("s is \"" + s + "\"");
        
        if(s.substring(1).equals("J"))
        {
            rank=11;
           
            
            
        }
        else if(s.substring(1).equals("Q"))
        {
            rank= 12;
      
        }
        else if(s.substring(1).equals("K"))
        {
            rank=13;
            
        }
        else if(s.substring(1).equals("A"))
        {
            rank=1;
        }
        else
        {
          rank=Integer.parseInt(s.substring(1));
            
        }
        
        if(s.substring(0,1).equals("D"))
        {
            suit="D";
            
        }
        else if(s.substring(0,1).equals("S"))
        {
            suit="S";
        }
         else if(s.substring(0,1).equals("C"))
        {
            suit="C";
        }
         else if(s.substring(0,1).equals("H"))
        {
            suit="H";
        }
        
        
       
        
    }
    
     public int getScore(){
         if(getRank()==1){
             return 11;
         }
         else if(getRank()<10){
             return getRank();
         }
         else{
             return 10;
         }
     }
     
    
     
    public String getSuit()
    {
        return suit;
    }
    
     public int getRank()
    {
        return rank;
    }
    
    public String pack()
    {
      String c="";
      String rank2;
          if(rank==11){
            rank2= "J";
           c= getSuit()+rank2; 
          }
          else if(rank==12){
            rank2= "Q";
           c= getSuit()+rank2; 
          }
          else if(rank==1){
              rank2="A";
              c=getSuit()+rank2;
          }
        else if(rank==13){
            rank2= "K";
           c= getSuit()+rank2; 
          }
        else{
        c= getSuit()+getRank();
       }
        return c;
    }
        //String c  = getSuit()+getRank();
      //return c;
    }
    



