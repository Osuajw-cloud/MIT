import java.awt.*;
import java.awt.event.*;
import java.net.*;
import javax.swing.*;
import java.util.*;
import java.io.*;

//The Display is the region in the window where drawing occurs.
public class Display extends JComponent implements
  MouseListener, Runnable //need for mouse input
{
  //main method for testing
  public static void main(String[] args)
  {
    Display display = new Display("169.254.54.69");
  }

  private Image image;  //image to draw
  private Image mid; 
  private ArrayList<Card> hand;
  private ArrayList<Card> dHand;
  private Image pokeChips;
  private BufferedReader in; //for receiving messages from the server
    private PrintWriter out;
    
    
    private static final int BETTING = 1;
    private static final int PLAYING=2;
    private static final int WAITING=3;
    // private static final int WIN=4;
    // private static final int push=5;
    // private static final int lose=6;
    private int mode;
    private int score;
    private int bet;
    private int earnings;
    private String sentence;
    
  public Display(String ipAddress)
  {
    //load image
    //Card card1= new Card("S", 5);
    
    //Card card2= new Card("H", 9);
    
     //Card card3= new Card("D", 10);
    
      // Card card4= new Card("C", 8);
     
    hand=new ArrayList<Card>();
    mode=BETTING;
    bet=0;
    earnings=1000;
    sentence="";
    score=0;
    
    
    // hand.add(card1);
    // hand.add(card2);
    // hand.add(card3);
    // hand.add(card4);
    
    
    //Card dCard = new Card("H", 6);
    
    dHand = new ArrayList<Card>();
    
    
    
    //dHand.add(dCard);
    
    String fileName = "casino.jpg";
    URL url = getClass().getResource(fileName);
    if (url == null)
      throw new RuntimeException("Unable to load:  " + fileName);
    image = new ImageIcon(url).getImage();
     String filzName="HitStandDouble.png";
     URL urz = getClass().getResource(filzName);
     if (urz == null)
      throw new RuntimeException("Unable to load:  " + filzName);
    mid = new ImageIcon(urz).getImage();
    String theFileName = "PokerChips.jpg";
    URL urd = getClass().getResource(theFileName);
    if (urd == null)
      throw new RuntimeException("Unable to load:  " + theFileName);
    pokeChips = new ImageIcon(urd).getImage();
    
    
    JFrame frame = new JFrame();  //create window
    frame.setTitle("BlackJack");  //set title of window
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //closing window will exit program
    setPreferredSize(new Dimension(1000, 1000));  //set size of drawing region
    
    //need for mouse input
    addMouseListener(this);  //will notify Display when the mouse is pressed
    
    frame.getContentPane().add(this);  //add drawing region to window
    frame.pack();  //adjust window size to fit drawing region
    frame.setVisible(true);  //show window
     try
        {
            //connect to server running on port 9000 of given ipAddress
            Socket socket = new Socket(ipAddress, 9000);
            
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);
        }
        catch(IOException e)
        {
            throw new RuntimeException(e);
        }

        new Thread(this).start();
  }
    
  
  public void run()
    {
        //
        
        while (true)
        {
            System.out.println("mode = " + mode);
            try
            {
                String message = in.readLine();
                System.out.println("Client received: " + message);

                //convert message string into array of tokens (originally separated by spaces)
                String[] tokens = message.split(" ");
                
                if (tokens[0].equals("Hand")|| tokens[0].equals("PlayerCard"))
                {
                   System.out.println("received hand!");
                   System.out.println("tokens: " + Arrays.toString(tokens));
                   for (int i = 1; i < tokens.length;i++)
                {
                   Card card= new Card(tokens[i]);
                   hand.add(card);
                }
                
                }
                
                
                if(tokens[0].equals("DealerCard"))
                {
                    System.out.println("received dealer card!");
                System.out.println("tokens: " + Arrays.toString(tokens));
                for(int i=1; i<tokens.length;i++)
                {
                    Card card=new Card(tokens[i]);
                    dHand.add(card);
                    
                    
                    
                }
                   // repaint();
                }
                if(tokens[0].equals("WIN"))
                {
                    earnings+=Integer.parseInt(tokens[1])-bet;
                    
                    repaint();
                    try{Thread.sleep(100);}catch(Exception e){}
                    JOptionPane.showMessageDialog(this, "you be winner");
                    send("READY");
                    mode=BETTING;
                    hand= new ArrayList<Card>();
                    dHand= new ArrayList<Card>();
                    bet=0;
                    sentence="";
                    score=0;
                    
                    //send message to server to say ready for next hand
                }
                if (tokens[0].equals("PUSH"))
                {
                    repaint();
                    try{Thread.sleep(100);}catch(Exception e){}
                    JOptionPane.showMessageDialog(this, "you be winner!");
                    send("READY");
                    mode=BETTING;
                    hand= new ArrayList<Card>();
                    dHand= new ArrayList<Card>();
                    bet=0;
                    sentence="";
                    score=0;
                    
                     //earnings-=Integer.parseInt(tokens[1])-bet;
                }
                if(tokens[0].equals("LOSE"))
                {
                    earnings+=Integer.parseInt(tokens[1]);
                    
                    repaint();
                    try{Thread.sleep(100);}catch(Exception e){}
                    JOptionPane.showMessageDialog(this, "you be loser");
                    send("READY");
                    mode=BETTING;
                    hand= new ArrayList<Card>();
                    dHand= new ArrayList<Card>();
                    bet=0;
                    sentence="";
                    score=0;
                    
                    //send message to server to say ready for next hand
                }
                if (tokens[0].equals("BUST"))
                {
                    sentence="You Busted";
                    mode=WAITING;
                }
                if (tokens[0].equals("SCORE"))
                {
                    score=Integer.parseInt(tokens[1]);
                }
                if(tokens[0].equals("GAMEOVER"))
                {
                    try{Thread.sleep(100);}catch(Exception e){}
                    JOptionPane.showMessageDialog(this, "Game Over"+"Total: "+tokens[1]);
                    //send("READY");
                    mode=BETTING;
                    hand= new ArrayList<Card>();
                    dHand= new ArrayList<Card>();
                    bet=0;
                    sentence="";
                    score=0;
                    earnings=1000;
                    repaint();
                    //send message to server to say ready for next hand
                }
                

                
                
                
                repaint();
            }
            catch(IOException e)
            {
                throw new RuntimeException(e);
            }
        }
    }
  
  
    public void send(String message)
    {
        System.out.println("Client sending: " + message);
        out.println(message);
    }
    
    
  //called automatically when Java needs to draw the Display
  public void paintComponent(Graphics g)
  {
    System.out.println("mode = " + mode);
      
    int width = getWidth();  //get width of drawing region
    int height = getHeight();  //get height of drawing region
    g.setColor(Color.WHITE);  //set pen color to white
    g.fillRect(0, 0, width, height);  //fill with white rectangle
    g.drawImage(image, 0,0 , 1000, 1000, null);//draw image.gif
    g.drawImage(mid, 300, 350, 400,150, null);
    if(hand.size()>2){
        g.setColor(new Color(150,150,150,150));
        g.fillRect(567,350,133,150);
    }
    g.setColor(Color.WHITE);
    if(mode==BETTING)
    {    g.drawImage(pokeChips, 30, 370, 250,150, null);

        
    }
    // if(mode==WIN)
    // {
        // //update new number
        
        // g.setFont(new Font("arial", Font.BOLD, 32));
        // g.drawString("You WIN!", 500, 325);
        // //earnings= bet+
        
        
    // }
    // if (mode==push)
    // {
        // g.setFont(new Font("arial", Font.BOLD, 32));
        // g.drawString("TIE", 500, 325);
    // }
    if (mode==WAITING )
    {
       // update new number
       g.setFont(new Font("arial", Font.BOLD, 32));
        g.drawString(sentence, 500, 325);
    }
    
    
    
    //g.drawImage(pokeChips, 30, 370, 250,150, null);
    // Card card = hand.get(0);
    // String c = "Cards" + File.separator + card.pack() + ".png";
    g.setFont(new Font("arial", Font.BOLD, 32));
    g.drawString("Total Earnings:", 10, 40);
    g.drawString("Total Bet:", 50, 325);
    g.drawString("Dealer Hand:",400, 50);
    g.drawString("Your Hand:", 400, 530);
    g.drawString("Score:", 50, 600);
    g.drawString( String.valueOf(score)  , 154, 602);
    g.drawString( String.valueOf(earnings)  , 100, 100);
    g.drawString(String.valueOf(bet), 220, 325);
    
    // URL url = getClass().getResource(c);
    // if (url == null)
      // throw new RuntimeException("Unable to load:  " + c);
    // Image cardImage = new ImageIcon(url).getImage();
    int x=400;
    for(int i=0; i<hand.size(); i++)
    {
        Card card = hand.get(i);
    String c = "Cards" + File.separator + card.pack() + ".png";
    
    URL url = getClass().getResource(c);
    if (url == null)
      throw new RuntimeException("Unable to load:  " + c);
    Image cardImage = new ImageIcon(url).getImage();
        g.drawImage(cardImage, x, 550, 100, 175, null);
        x+=50;
        
    }
    // int y = 400;
    // for(int i=0; i<hand.size(); i++)
    // {
        // Card card = hand.get(i);
    // String c = "Cards" + File.separator + card.pack() + ".png";
   
    // URL url = getClass().getResource(c);
    // if (url == null)
      // throw new RuntimeException("Unable to load:  " + c);
    // Image cardImage = new ImageIcon(url).getImage();
        // g.drawImage(cardImage, y, 100,100 ,175, null);
        // y+=50;
        
    // }
    
    
    
    
    
    
    
    int x2=400;
    for(int i=0; i<dHand.size(); i++)
    {
        Card card = dHand.get(i);
    String c = "Cards" + File.separator + card.pack() + ".png";
    
    URL url = getClass().getResource(c);
    if (url == null)
      throw new RuntimeException("Unable to load:  " + c);
    Image cardImage = new ImageIcon(url).getImage();
        g.drawImage(cardImage, x2, 100, 100, 175, null);
        x2+=50;
        
    }
    // int y2 = 200;
    // for(int i=0; i<dHand.size(); i++)
    // {
        // Card card = dHand.get(i);
    // String c = "Cards" + File.separator + card.pack() + ".png";
   
    // URL url = getClass().getResource(c);
    // if (url == null)
      // throw new RuntimeException("Unable to load:  " + c);
    // Image cardImage = new ImageIcon(url).getImage();
        // g.drawImage(cardImage, y2, 100,100 ,175, null);
        // y2+=50;
        
    // }
    
    // if(mode==BETTING)
    // {
        // if(
        // {}
    // }
    
    
    
    //g.drawImage(cardImage, 450, 550, 100, 175, null);
  }
  
  //need for mouse input
  public void mousePressed(MouseEvent e)
  {
    int x = e.getX();  //get x-coordinate of mouse
    int y = e.getY();  //get y-coordinate of mouse
    if(mode==PLAYING){
    if(x>313&&x<427&&(y>375&&y<485))
    {
        send("HIT");
    }
    if(x>445&&x<557&&(y>375&&y<485))
    {
        sentence= "STAND";
       send("STAND");
       mode=WAITING;
    }
   
    if(x>575&&x<689&&(y>375&&y<485)&&hand.size()==2)
    {
       send("DOUBLE");
       if(earnings>=bet*2)
       {
           bet=bet*2;
       }
       mode=WAITING; // other witing mode?
    }
}
    // CHips
    else if(mode==BETTING)
    {
    if(x>43&&x<99&&(y>417&&y<477))
    {
        send("BET 10" );
        bet=10;
        mode=PLAYING;
    }
    if(x>101&&x<149&&(y>417&&y<477))
    {
        send("BET 50" );
        bet=50;
        mode=PLAYING;
    }
    if(x>154&&x<202&&(y>417&&y<477))
    {
        send("BET 100" );
        bet=100;
        mode=PLAYING;
    }
    if(x>206&&x<264&&(y>417&&y<477))
    {
        send("BET 500" );
        bet=500;
        mode=PLAYING;
        
    }
    }
    
    //System.out.println("mouse clicked:  " + x + ", " + y);
    repaint();  //indicates Display must be redrawn (Java will call paintComponent)
  }
  public void mouseReleased(MouseEvent e) { }
  public void mouseClicked(MouseEvent e) { }
  public void mouseEntered(MouseEvent e) { }
  public void mouseExited(MouseEvent e) { }
}