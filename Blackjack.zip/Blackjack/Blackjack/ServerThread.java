import java.io.*;
import java.net.*;
import java.util.*;
public class ServerThread extends Thread
{
    private int playerNum;
    private BufferedReader in;  //for receiving messages from this player's client
    private PrintWriter out;  //for sending messages to this player's client
    private Server server;  //for sending messages to opponent
    private ArrayList<Card> playerHand;
    private boolean turnDone;
    private boolean betDone;
    private int playerBet;
    private int totalEarnings;
    private boolean isReady;
    public ServerThread(Socket socket, Server server, int playerNum) throws IOException
    {
        this.server = server;
        this.playerNum = playerNum;
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        out = new PrintWriter(socket.getOutputStream(), true);
        playerHand= new ArrayList<Card>();
        turnDone=false;
        betDone=false;
        playerBet=0;
        totalEarnings=1000;
        isReady=false;
        start();
        //the run method has started
    }

    public void addCard(Card c){
        playerHand.add(c);
    }

       public void zeroPlayer(){
        playerHand= new ArrayList<Card>();
        playerBet=0; 
        isReady=false;
        turnDone=false;
        betDone=false;
    }
    
      public void zeroTotalPlayer(){
        playerHand= new ArrayList<Card>();
        System.out.println("ITS RUNNING");
        playerBet=0; 
        isReady=false;
        turnDone=false;
        betDone=false;
        totalEarnings=1000;
    }
    
    public int getTotalEarnings(){
        return totalEarnings;
    }
    
    // make dealer hand adding
    public void sendHand(){
        String hand = "Hand ";
        for(int x=0; x<playerHand.size(); x++){
            hand = hand+ playerHand.get(x).pack() +" ";
        }   
        send(hand);
    }

    public void sendDealerCard(Card dealerCard){
        String hand = "DealerCard ";
            hand = hand+ dealerCard.pack() +" ";
        send(hand);
    }
    
    public void sendPlayerCard(Card playerCard){
        String hand = "PlayerCard ";
            hand = hand+ playerCard.pack() +" ";
        send(hand);
    }
    
    public void sendTotalEarnings(Card playerCard){
        String pool = "TotalEarnings ";
         send(""+totalEarnings);
    }
    //keep receiving messages from this player's client
    public void run()
    {
        try
        {
            while (true)
            {
                String message = in.readLine();
                System.out.println("ServerThread " + playerNum + " received: " + message);
                //convert message string into array of tokens (originally separated by spaces)
                String[] tokens = message.split(" ");

                if (tokens[0].equals("HIT")){
                    Card c= server.dealCard();
                    addCard(c);
                    sendPlayerCard(c);
                    send("SCORE "+Server.getScore(playerHand));
                    
                        if(hasBusted()){
                        turnDone=true;
                        send("BUST");
                        server.playerDone();
                    }
                    
                        
                } 

                else if (tokens[0].equals("STAND")){
                    turnDone=true; 
                    server.playerDone();
                    //while dealer hans't busted and isnt above 16, hit
                }

                else if (tokens[0].equals("DOUBLE")){
                    playerBet=playerBet*2;
                    Card c= server.dealCard();
                    addCard(c);
                    sendPlayerCard(c);
                    send("SCORE "+Server.getScore(playerHand));
                    
                        if(hasBusted()){
                      send("BUST");
                    }
                    
                    turnDone=true;
                    server.playerDone();
                }
                else if(tokens[0].equals("BET")){
                    playerBet= Integer.parseInt(tokens[1]);
                    totalEarnings-=Integer.parseInt(tokens[1]);
                    send("SCORE "+Server.getScore(playerHand));
                    betDone=true;
                    server.bettingDone();
                    //make sure all done works, then if won add 
                }
                 else if(tokens[0].equals("TOTAL")){
                    send(""+totalEarnings);
                    //make sure all done works, then if won add 
                }
                 else if(tokens[0].equals("READY")){
                    isReady=true;
                    server.playerReady();
                    //make sure all done works, then if won add 
                }
                // where to see if turn done and ehat to do about it next
            }
        }
        catch(IOException e)
        {
            throw new RuntimeException(e);
        }
    }
    
    public boolean hasBusted(){
        if(Server.getScore(playerHand)>21){
            return true;
        }
        return false;
    }
    
    public void addToTotal(int i){
        totalEarnings+=i;
    }
    
    public int getPlayerBet(){
          return playerBet ;   
        }

     public boolean turnDone(){
        if(turnDone){
            return true;
        }
        return false;
    }
    
     public boolean isReady(){
        return isReady;
    }
    
       public boolean betDone(){
        if(turnDone){
            return true;
        }
        return false;
    }

        public ArrayList getPlayerHand(){
            return playerHand;
        }
    
    //send message to this player's client
    public void send(String message)
    {
        System.out.println("ServerThread " + playerNum + " sending: " + message);
        out.println(message);
    }
}