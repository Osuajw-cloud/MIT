import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

//D= diamond, S= Spade, H= heart, C= club
public class Server
{
    private List<ServerThread> threads;
    private List<ServerSocket> sockets;
    private List<Card> deck;
    private Card dealerCard;
      private ArrayList<Card> dealerHand;
      private int numRoundsPlayed;
    public Server()
    {
        threads= new ArrayList<ServerThread>();
        try
        {
            //start listening for connections on port 9000
            ServerSocket serverSocket = new ServerSocket(9000); 

            for(int x=1; x<=2;x++){
                Socket socket = serverSocket.accept();
                threads.add(new ServerThread(socket, this, x));
            }
            numRoundsPlayed=0;
             createHand();
        
    }
        catch(IOException e)
        {
            throw new RuntimeException(e);
        }
    }

    public static int getScore(ArrayList<Card> c){
        int numAces=0;
        int score=0;
        
        for(int x=0; x<c.size();x++){
            score+= c.get(x).getScore();  
        }
         for(int x=0;x<c.size();x++){
            if(c.get(x).getRank()==1){
                numAces++;
            }
        }
        while(score>21 && numAces>0){
            score-=10;
            numAces--;
            
        }
        
        return score;
    }
    
    //send message to other player
    public void sendToOpponent(String message, int playerNum)
    {
        if (playerNum == 1)
            threads.get(1).send(message);
        else if(playerNum == 2){
            threads.get(2).send(message);
        }
        else{
            threads.get(0).send(message);
        }
    }
    
    public Card dealCard(){
        Card c= deck.get(0);
        deck.remove(0);
        return c;
    }

      public int getDealerScore(){
        int score=0;
        for(int x=0; x<dealerHand.size();x++){
            score+= dealerHand.get(x).getScore();  
        }
        return score;
    }

      public boolean dealerHasBusted(){
         
        if(getScore(dealerHand)>21){
            return true;
        }
        return false;
    }    //Fix Dealer Aces, then make it so after number of rounds player with most money wins
    
      public void addDealerCard(Card c){
        dealerHand.add(c);
    }
    
    public void playerReady(){
        boolean allReady=true;
        for(int q=0;q<threads.size();q++){
            if(!threads.get(q).isReady()){
                allReady=false;
            }
            }
            if(allReady){
                createHand();
            }
    }
    
    public void playerDone(){
        boolean playerDone=true;
        for(int x=0;x<threads.size();x++){
            if(threads.get(x).turnDone()==false){
                playerDone=false;
            }
        }
        if(playerDone==true){
            while(getDealerScore()<16 && !dealerHasBusted()){
                Card c=dealCard();
                for(int x=0;x<threads.size();x++){
                    threads.get(x).sendDealerCard(c);
                }
                addDealerCard(c);
            }
            
            for(int x=0;x<threads.size();x++){
                 if( threads.get(x).hasBusted()){
                threads.get(x).send("LOSE "+"-"+threads.get(x).getPlayerBet());
            }
            else if(getScore(threads.get(x).getPlayerHand())>getDealerScore()&& getScore(threads.get(x).getPlayerHand())<=21){
                threads.get(x).addToTotal(threads.get(x).getPlayerBet()*2);
                threads.get(x).send("WIN "+""+threads.get(x).getPlayerBet()*2);
            }
            else if(getScore(threads.get(x).getPlayerHand())==getDealerScore()&& getScore(threads.get(x).getPlayerHand())<=21){
                threads.get(x).addToTotal(threads.get(x).getPlayerBet());
                threads.get(x).send("PUSH "+""+threads.get(x).getPlayerBet());
            }
            else if(getDealerScore()>21){
                 threads.get(x).addToTotal(threads.get(x).getPlayerBet()*2);
                threads.get(x).send("WIN "+""+threads.get(x).getPlayerBet()*2);
            }
            
            else if(getScore(threads.get(x).getPlayerHand())<getDealerScore()){
                threads.get(x).send("LOSE "+"-"+threads.get(x).getPlayerBet());
            }
            numRoundsPlayed++;
        }
        if(numRoundsPlayed>=10){
             for(int x=0;x<threads.size();x++){
              threads.get(x).send("GAMEOVER "+threads.get(x).getTotalEarnings());
             threads.get(x).zeroTotalPlayer();
            }
            numRoundsPlayed = 0;
            //RESET PLAYER CARDS
        // int biggest=0;
        // int spot=0;
        // for(int x=0;x<threads.size();x++){
            // int player= threads.get(x).getTotalEarnings();
            // if(player>biggest){
                // biggest=player;
                // spot=x;
            // }
            // threads.get(x).zeroTotalPlayer();
        // }
        // if(spot==0){
        // threads.get(0).send("GAMEOVER WINNER ");
        // threads.get(1).send("GAMEOVER LOSER ");
        // threads.get(2).send("GAMEOVER LOSER ");
    // }
    // else if(spot==1){
      // threads.get(0).send("GAMEOVER LOSER ");
        // threads.get(1).send("GAMEOVER WINNER ");
        // threads.get(2).send("GAMEOVER LOSER ");  
    // }
    // else{
        // threads.get(0).send("GAMEOVER LOSER ");
        // threads.get(1).send("GAMEOVER LOSER ");
        // threads.get(2).send("GAMEOVER WINNER ");
    // }
    // }
}
}
}
    public void bettingDone(){
        boolean allDone=true;
        for(int x=0;x<threads.size();x++){
            if(threads.get(x).betDone()==false){
                allDone=false;
            }
        }
    }

    public void createHand(){
         deck= new ArrayList<Card>();
        dealerHand= new ArrayList<Card>();
         for(int x=0;x<threads.size();x++){
                threads.get(x).zeroPlayer();
            }
        for(int x=1; x<14;x++){
            deck.add(new Card("S",x)); 
        }
        for(int x=1; x<14;x++){
            deck.add(new Card("D",x)); 
        }
        for(int x=1; x<14;x++){
            deck.add(new Card("C",x)); 
        }
        for(int x=1; x<14;x++){
            deck.add(new Card("H",x)); 
        }
        Collections.shuffle(deck);
        dealerCard=dealCard();

            for(int x=0;x<threads.size();x++){
                threads.get(x).addCard(deck.get(0));
                deck.remove(0);
                threads.get(x).addCard(deck.get(0));
                deck.remove(0);
            }

            for(int x=0;x<threads.size();x++){
                threads.get(x).sendHand();
            }

            for(int x=0;x<threads.size();x++){
                threads.get(x).sendDealerCard(dealerCard);
            }
            addDealerCard(dealerCard);
    }
    
    
    
}