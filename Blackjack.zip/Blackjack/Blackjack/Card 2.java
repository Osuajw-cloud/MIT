
public class Card
{
    // instance variables - replace the example below with your own
    private int rank;
    private String rank2;
    private String suit;  
   
    public Card(String s, int r)
    {
       rank=r;
       suit=s;

    }

 
    public String getSuit()
    {
        return suit;
    }
    
     public int getRank()
    {
        return rank;
    }
    
    public String pack(){
        String c="";
        if(rank==11){
            rank2= "J";
           c= getSuit()+rank2; 
        }
        else if(rank==12){
            rank2= "Q";
           c= getSuit()+rank2; 
        }
        else if(rank==13){
            rank2= "K";
           c= getSuit()+rank2; 
        }
        else{
        c= getSuit()+getRank();
    }
        return c;
    }
    
}
