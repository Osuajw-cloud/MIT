public class Block
{
    private GridDisplay display;
    private Color color;
    private Location[] locs;

    public Block(GridDisplay disp)
    {
        display=disp;
        int shapeNum = (int)(Math.random() * 7);
        if (shapeNum == 0)
        {
            color = new Color(255, 0, 255);
        locs= new Location[4];
        locs[0]= new Location(0,4);
        locs[1]= new Location(0,3);
        locs[2]= new Location(0,5);
        locs[3]= new Location(0,6);
        }
        else if (shapeNum == 1)
        {
            color = new Color(255, 255, 0);
            locs= new Location[4];
        locs[0]= new Location(0,4);
        locs[1]= new Location(0,5);
        locs[2]= new Location(1,4);
        locs[3]= new Location(1,5);
        }
        else if (shapeNum == 3)
        {
            color = new Color(0, 255, 255);
              locs= new Location[4];
        locs[0]= new Location(0,4);
        locs[1]= new Location(0,3);
        locs[2]= new Location(0,5);
        locs[3]= new Location(1,4);
        }
        else if (shapeNum == 4)
        {
            color = new Color(225, 165, 0);
            locs= new Location[4];
        locs[0]= new Location(0,4);
        locs[1]= new Location(0,5);
        locs[2]= new Location(0,6);
        locs[3]= new Location(1,6);
        }
        else if (shapeNum == 5){
           color = new Color(225, 0, 0);
            locs= new Location[4];
        locs[0]= new Location(0,4);
        locs[1]= new Location(0,5);
        locs[2]= new Location(1,5);
        locs[3]= new Location(1,6);
  
        }
        else if (shapeNum == 6){
           color = new Color(0, 225, 0);
            locs= new Location[4];
        locs[0]= new Location(1,4);
        locs[1]= new Location(1,5);
        locs[2]= new Location(0,5);
        locs[3]= new Location(0,6);
  
        }
        else{
             color = new Color(150, 20, 175);
            locs= new Location[4];
        locs[0]= new Location(0,4);
        locs[1]= new Location(1,4);
        locs[2]= new Location(0,5);
        locs[3]= new Location(0,6);
        }
        drawSelf(color);
    }

    public void drawSelf(Color color)
    {for(int x=0;x<locs.length;x++){
        display.setColor(locs[x],color);
    }
    }

    public boolean areValidAndEmpty(Location[] locs)
    {
        boolean valid=true;
        Color a= new Color(0,0,0);
        int c=display.getNumCols();
        int r=display.getNumRows();
        for(int x=0;x<locs.length;x++){
            Location n=locs[x];
            if(n.getRow()>=r || n.getCol()>=c||n.getRow()<0||n.getCol()<0){
                valid=false;
            }
            else if(valid==true){
            Color t= display.getColor(n);
            if(!t.equals(a)){
                valid=false;
            }
            }
        }
        return valid; 
    }

    public boolean shift(int deltaRow, int deltaCol)
    {
        Color Black= new Color(0,0,0);
        boolean move= false;
        Location[] others= new Location[locs.length];
        drawSelf(Black);
        for(int x=0; x<locs.length;x++){
         others[x]= new Location(locs[x].getRow()+deltaRow,locs[x].getCol()+deltaCol);
        }
             if(areValidAndEmpty(others)== true){
          move=true;
          locs=others;
          drawSelf(color);
        }
        else{
         drawSelf(color);
         move=false;
        }
        return move; 
    }

    public void rotate()
    {
        Color Black= new Color(0,0,0);
        boolean move= false;
        Location[] others= new Location[locs.length];
        drawSelf(Black);
        for(int x=0; x<locs.length;x++){
         others[x]= new Location(locs[0].getRow()+locs[x].getCol()-locs[0].getCol(),locs[0].getCol()+locs[0].getRow()-locs[x].getRow());
        }
             if(areValidAndEmpty(others)== true){
          move=true;
          locs=others;
          drawSelf(color);
        }
        else{
         drawSelf(color);
         move=false;
        }
    }
    
}