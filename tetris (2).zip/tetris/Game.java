public class Game
{
    
    private GridDisplay display;
    private Block block;
    private int score;
    private int level;
    private int numCompleted;
    public Game()
    {
        display = new GridDisplay(20, 10);
        display.setTitle("Tetris");
        display.setLineColor(new Color(0, 0, 0));
        block=new Block(display);
        score=0;
        level=1;
        numCompleted=0;
    }

    public void play()
    {
        int p=3;
        int leveler=10;
        int after=0;
        int j=50;
        while (true)
        {
            display.setTitle("score: "+ score+"       Level: "+level);
            //loop to process 10 key presses in half a second
            for (int i = 0; i < 10; i++)
            {
                display.pause(j);
                int key = display.checkLastKeyPressed();
                if (key == 37)
                {
                    block.shift(0,-1);

                }
                else if (key == 38)
                {
                    block.rotate();

                }
                else if (key == 39)
                {
                    block.shift(0,1);

                }
                else if (key == 40)
                {
                    block.shift(1,0);

                }
                else if (key == 32){
                    for(int x=0; x<display.getNumRows();x++){
                        block.shift(1,0);
                    }
                }
            } //end of for-loop
            boolean c=block.shift(1,0);
            if(!c){
                removeCompletedRows();
                Location[] locs= new Location[display.getNumCols()];
                for(int x=0; x<display.getNumCols(); x++){
                    locs[x]= new Location(0,x);
                }
                if(block.areValidAndEmpty(locs)){
                block=new Block(display);
                after++;
                if(after%2==0){
                   j--; 
                }
                if(numCompleted>=leveler){
                    level++;
                    for(int x=0; x<display.getNumRows();x++){
                        removeRow(x);
                    }
                    numCompleted=0;
                    j=50;
                    j=j-p;
                    leveler+=2;
                    p=p+3;
                }
            }
            else{
                lose();
                System.exit(0);
            }
            }
           
    }
}

    public boolean isCompletedRow(int row)
    {
        boolean c=true;
        Color black= new Color(0,0,0);
        for(int x=0;x<display.getNumCols();x++){
         Location loc=new Location(row,x);
         Color current= display.getColor(loc);
         if(current.equals(black)){
             c=false;
         }
         
        }
        return c; 
    }

    public void removeSquare(Location loc)
    {
        Color black=new Color(0,0,0);
        Location top=new Location(0,loc.getCol());
        for(int x=1;x<loc.getRow()+1;x++){
           Color c= display.getColor(new Location(loc.getRow()-x,loc.getCol()));
           Location cur= new Location(loc.getRow()+1-x,loc.getCol());
            display.setColor(cur,c);
        }
        display.setColor(top,black);
    }

    public void removeRow(int row)
    {
        for(int x=0; x<display.getNumCols();x++){
            Location loc=new Location(row,x);
            display.setColor(loc, new Color(255,255,255));
            display.pause(15);
            removeSquare(loc);
        }
    }

    public void removeCompletedRows()
    {
       int rowsGone=0;
        for(int x=0;x<display.getNumRows();x++){
    if(isCompletedRow(x)){
        removeRow(x);
        rowsGone++;
        }
    }
    if(rowsGone==1){
        score+=100*level;
        numCompleted++;
    }
    else if(rowsGone==2){
        score+=300*level;
        numCompleted++;
    }
    else if(rowsGone==3){
        score+=500*level;
        numCompleted+=3;
    }
    else if(rowsGone==4){
        score+=800*level;
        numCompleted+=4;
    }
    
}

public void lose()
    {
        System.out.println("Game Over!"); 
        System.out.print("You scored ");   
        System.out.print(score);  
        System.out.print(" points"); 
        }
    }