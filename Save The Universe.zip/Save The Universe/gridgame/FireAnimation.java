public class FireAnimation
{
    private int row;
    private int col;
    private int stage = 0;
    private boolean isRed;
    
    private int delayCounter = 0;   // new delay counter
    private static final int DELAY_LIMIT = 6;  // controls animation speed (higher = slower)

    public FireAnimation(int r, int c, boolean red)
    {
        row = r;
        col = c;
        isRed = red;
    }

    public boolean animate(int[][] foreground)
    {
        delayCounter++;

        if (delayCounter >= DELAY_LIMIT) {
            delayCounter = 0;
            stage++;
        }

        if(isRed == false) {
            if(stage < 5) {
                if(stage % 2 == 0) {
                    foreground[row][col] = 47;
                } else {
                    foreground[row][col] = 48;
                }
                return false;
            } else {
                foreground[row][col] = 2;
                return true;
            }
        } else {
            if(stage < 8) {
                if(stage % 2 == 0) {
                    foreground[row][col] = 70;
                } else {
                    foreground[row][col] = 71;
                }
                return false;
            } else {
                foreground[row][col] = 2;
                return true;
            }
        }
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }

    public boolean isRed() {
        return isRed;
    }
}
