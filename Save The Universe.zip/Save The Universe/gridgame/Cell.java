public class Cell 
{
  private Color color;
  private String foreImage;
  private String backImage;

  public Cell()
  {
    color = new Color(0, 0, 0);
    backImage = null;
    foreImage=null;
     
    }
  
  
  public void setColor(Color c)
  {
    color = c;
  }
  
  public Color getColor()
  {
    return color;
  }
  
  public String getBackImage()
  {
    return backImage;
  }
  
  public String getForeImage()
  {
    return foreImage;
  }
  
  public void setBackImage(String fileName)
  {
    backImage = fileName;
  }
  
  public void setForeImage(String fileName)
  {
    foreImage = fileName;
  }
  
}
