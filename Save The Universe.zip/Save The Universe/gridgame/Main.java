
public class Main
{
    public static void Main(String[] args)
    {
        Game g = new Game();
        g.play();
    }

   
}
