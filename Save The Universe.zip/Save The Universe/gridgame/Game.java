import java.util.ArrayList;
import java.util.HashSet;

public class Game
{
    private GridDisplay display;
    private GridDisplay titleDisplay;
    private boolean runTitle;
    private Location heroLoc;
    private String StraightL;
    private String StraightR;
    private String LeftS;
    private String LeftW;
    private String RightS;
    private String RightW;
    private String BackL;
    private String BackR;
    private int counter=2;
    private int num=1;
    private int bossNum=1;
    private String direction="down";
    private int worldRow; // player's position in the world
    private int worldCol;
    private int[][]background;
    private int[][]foreground;
    ArrayList<String> images= new ArrayList<String>();
    private boolean hasSword=false;
    private int health;
    private int bossHealth;
    private int bossCounter;
    private boolean finalForm;
    private boolean isRed;
    private ArrayList<Integer> pendingFireRows = new ArrayList<>();
    private      ArrayList<Integer> pendingFireCols = new ArrayList<>();
    private      ArrayList<Long> warningStartTimes = new ArrayList<>();
    private     ArrayList<Integer> pendingFireTypes = new ArrayList<>();
    //Boss Combat
    private int pendingfireType=-1;
    int pendingFireRow=-1;
    int pendingFireCol=-1;
    boolean warningActive= false;
    long warningStartTime=0;
    int oldPlayerRow=-1;
    int oldplayerCol=-1;
    private ArrayList<FireAnimation> fires= new ArrayList<FireAnimation>();
    private static final long WARNING_DURATION=3000;

    public Game()
    {
        System.out.println("Save The Universe:");
        System.out.println("Hey, welcome to my game!");
        System.out.println("Prologue:");
        System.out.println("Our story begins with a young adventurer ");
        System.out.println("traversing a land seemingly untouched by time.");
        System.out.println("He has been searching for");
        System.out.println("the legendary ancient sword,");
        System.out.println("The Hyperion!");
        System.out.println("He is destined to find this sword in order");
        System.out.println("to slay Emperor Tarrow,the evil sorcerer.");
        System.out.println();
        System.out.println("Controls:");
        System.out.println("W - move up");
        System.out.println("A - move left");
        System.out.println("S - move down");
        System.out.println("D - move right");
        System.out.println("E - interact/attack");
        System.out.println("");
        System.out.println("Tip:");
        System.out.println("If you see an exclamation point");
        System.out.println("above your head, move!");
        runTitle=true;
        titleDisplay = new GridDisplay(1, 1);
        titleDisplay.setBackImage(new Location(0,0),"title1.png");
        int key=0;
        finalForm=false;
        while (runTitle)
        {
            titleDisplay.pause(50);
            key = titleDisplay.checkLastKeyPressed();
            if(key!=1){
                keyTitlePressed(key);
            }
        }
        display = new GridDisplay(13, 17);
        display.setTitle("Save The Universe"); 
        heroLoc = new Location(6, 8);
        StraightL = "StraightL.png";
        StraightR = "StraightR.png";
        LeftS = "LeftS.png";
        LeftW="LeftW.png";
        RightS="RightS.png";
        RightW="RightW.png";
        BackL="BackL.png";
        BackR="BackR.png";
        health=3;
        bossHealth=60;
        display.setForeImage(heroLoc, StraightL);
        worldRow=6;
        worldCol= 8;
        images.add("tree.png"); // 0
        images.add("grass.png"); // 1
        images.add(null); // 2
        images.add("trail.png"); // 3
        images.add("trailS.png"); // 4
        images.add("trailEndT.png"); // 5
        images.add("trailEndB.png"); // 6
        images.add("trailEndL.png"); // 7
        images.add("trailEndR.png"); // 8
        images.add("turnTR.png"); // 9
        images.add("turnBR.png"); // 10
        images.add("turnTL.png"); // 11
        images.add("turnBL.png"); // 12
        images.add("cave.png"); // 13
        images.add("cobblestone.png"); // 14
        images.add("cobbleBR.png"); // 15
        images.add("cobbleBL.png"); // 16
        images.add("cobbleTL.png"); // 17
        images.add("cobbleTR.png"); // 18
        images.add("sword.png"); // 19
        images.add("chest.png"); // 20
        images.add("potion.png"); // 21
        images.add("openchest.png"); // 22
        images.add("bosshead.png"); // 23
        images.add("attackTS.png"); // 24
        images.add("attackRS.png"); // 25
        images.add("attackBS.png"); // 26
        images.add("attackLS.png"); // 27
        images.add("attackT.png"); // 28
        images.add("attackR.png"); // 29
        images.add("attackB.png"); // 30
        images.add("attackL.png"); // 31
        images.add("bossbody.png"); // 32
        images.add("bossbody2.png"); // 33
        images.add("bosshead2.png"); // 34
        images.add("bosshurthead.png"); // 35
        images.add("bosshurthead2.png"); // 36
        images.add("bosshurtbody.png"); // 37
        images.add("bosshurtbody2.png"); // 38
        images.add("bosshurtheadS.png"); // 39
        images.add("bosshurtheadS2.png"); // 40
        images.add("bosshurtheadSL.png"); // 41
        images.add("bosshurtheadSR.png"); // 42
        images.add("bosshurthead2SL.png"); // 43
        images.add("bosshurthead2SR.png"); // 44
        images.add("bosshurtbodySL.png"); // 45
        images.add("bosshurtbodySR.png"); // 46
        images.add("fire.png"); // 47
        images.add("bigfire.png"); // 48
        images.add("onfireR.png"); // 49
        images.add("onfireL.png"); // 50
        images.add("onfireB.png"); // 51
        images.add("bossheadfinal.png"); // 52
        images.add("bossbodyfinal.png"); // 53
        images.add("bossbodyfinal2.png"); // 54
        images.add("bossfinallegL.png"); // 55
        images.add("bossfinallegR.png"); // 56
        images.add("bossfinalarmR.png"); // 57
        images.add("bossfinalarmL.png"); // 58
        images.add("title1.png"); // 59
        images.add("title2.png"); // 60
        images.add("title3.png"); // 61
        images.add("title4.png"); // 62
        images.add("title5.png"); // 63
        images.add("exclamationpoint.png"); // 64
        images.add("gameOver2.png"); // 65
        images.add("gameOver3.png"); // 66
        images.add("gameOver4.png"); // 67
        images.add("gameOver1.png"); // 68
        images.add("onfireT.png"); // 69
        images.add("redfire.png"); // 70
        images.add("redfire2.png"); // 71
        images.add("bossheadfinalhurt.png"); // 72 // 70
        images.add("bossbodyfinalhurt.png"); // 73
        images.add("bossbodyfinal2hurt.png"); // 74
        images.add("bossfinallegLhurt.png"); // 75
        images.add("bossfinallegRhurt.png"); // 76
        images.add("bossfinalarmRhurt.png"); // 77
        images.add("bossfinalarmLhurt.png"); // 78 
        background = new int[][]{
            {1,1,16,14,14,14,14,14,14,14,14,14,14,14,15,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,16,14,14,14,14,14,14,14,14,14,15,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,14,14,14,14,14,14,14,14,14,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,16,14,14,14,14,14,14,14,15,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,16,14,14,14,14,14,15,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,1,1,16,14,15,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,1,1,1,5,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,1,1,1,12,4,4,4,4,9,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,3,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,1,1,1,5,1,1,1,1,3,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,1,1,1,3,1,1,1,1,3,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,1,1,1,12,4,4,4,4,10,1,1,1,1,1,1,1,1,1,14,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,17,14,18,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,17,14,14,14,18,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,14,14,14,14,14,14,14,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,16,14,14,14,15,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,16,14,15,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,14,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
        };

        foreground = new int[][]{
            {2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2},
            {2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2},
            {2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2},
            {2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2},
            {2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2},
            {0,0,0,0,0,0,0,16,13,15,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,2,0,0,0,0,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,2,2,2,2,2,2,2},
            {2,2,2,2,2,2,2,0,2,2,2,2,2,2,0,2,2,2,0,2,2,2,2,21,2,2,2,0,0,2,2,2,2,2,2,2},
            {2,2,2,2,2,2,2,0,0,0,0,0,0,2,0,2,2,2,2,2,2,2,2,0,2,2,2,2,0,2,2,2,2,2,2,2},
            {2,2,2,2,2,2,2,0,20,0,0,0,0,2,0,2,2,2,2,2,2,2,2,2,2,2,2,2,0,2,2,2,2,2,2,2},
            {2,2,2,2,2,2,2,0,2,0,0,0,0,2,0,2,2,2,2,2,2,2,2,2,2,2,2,2,0,2,2,2,2,2,2,2},
            {2,2,2,2,2,2,2,0,2,0,0,0,0,2,0,2,2,2,2,2,2,2,2,2,2,2,2,2,0,2,2,2,2,2,2,2},
            {2,2,2,2,2,2,2,0,2,2,2,2,2,2,0,2,2,2,2,2,2,2,2,2,2,2,2,2,0,2,2,2,2,2,2,2},
            {2,2,2,2,2,2,2,0,2,0,0,0,0,0,2,2,2,2,2,2,2,2,2,2,2,2,0,21,0,2,2,2,2,2,2,2},
            {2,2,2,2,2,2,2,0,2,0,2,2,2,2,2,2,2,2,2,2,2,2,2,23,2,2,2,2,0,2,2,2,2,2,2,2},
            {2,2,2,2,2,2,2,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,32,2,2,2,2,0,2,2,2,2,2,2,2},
            {2,2,2,2,2,2,2,0,2,2,2,2,2,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,2,2,2,2,2,2,2},
            {2,2,2,2,2,2,2,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,2,2,2,2,2,2,2},
            {2,2,2,2,2,2,2,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,2,2,2,2,2,2,2},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {2,2,2,2,2,2,2,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2},
            {2,2,2,2,2,2,2,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2},
            {2,2,2,2,2,2,2,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2},
            {2,2,2,2,2,2,2,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2},
            {2,2,2,2,2,2,2,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2},
        };
    }

    public void update(){
        for(int row=0;row<display.getNumRows();row++){
            for(int col=0;col<display.getNumCols();col++){
                int imageNum= background[worldRow+row-6][worldCol+col-8];
                String image= new String(images.get(imageNum));
                display.setBackImage(new Location(row,col),image);
            }
        }

        for(int row=0;row<display.getNumRows();row++){
            for(int col=0;col<display.getNumCols();col++){  
                int imageNum= foreground[worldRow+row-6][worldCol+col-8];
                if(imageNum==2){
                    display.setForeImage(new Location(row,col),null);
                }
                else{
                    String image= new String(images.get(imageNum));
                    display.setForeImage(new Location(row,col),image);

                }
            }
        }
        if(health==3){
            display.setForeImage(new Location(0,0),"heart.png");
            display.setForeImage(new Location(0,1),"heart.png");
            display.setForeImage(new Location(0,2),"heart.png");
        }
        else if(health==2){
            display.setForeImage(new Location(0,0),"heart.png");
            display.setForeImage(new Location(0,1),"heart.png");
            display.setForeImage(new Location(0,2),"emptyheart.png");
        }
        else if(health==1){
            display.setForeImage(new Location(0,0),"heart.png");
            display.setForeImage(new Location(0,1),"emptyheart.png");
            display.setForeImage(new Location(0,2),"emptyheart.png");
        }
        else if(health==0){
            //implement tomorrow
        }

    }

    public void play()
    {
        while (true)
        {
            //wait 122 milliseconds for mouse or keyboard
            display.pause(250);
            bossCounter++;

            //check if any locations clicked or keys pressed
            Location clickLoc = display.checkLastLocationClicked();
            int key = display.checkLastKeyPressed();

            if (clickLoc != null)
            {
                //a location was clicked
                locationClicked(clickLoc);
            }

            if (key != -1)
            {
                //a key was pressed
                keyPressed(key);
            }
            update();
            step();
        }
    }

    //called when the user clicks on a location.
    //that location is passed to this method.
    private void locationClicked(Location loc)
    {

    }

    //called when the user presses a key.
    //each key on the keyboard has a unique key code.
    private void keyTitlePressed(int key){
        if(key==10){
            titleDisplay.setBackImage(new Location(0,0),"title2.png");
            titleDisplay.pause(1000);

            titleDisplay.setBackImage(new Location(0,0),"title3.png");
            titleDisplay.pause(1000);

            titleDisplay.setBackImage(new Location(0,0),"title4.png");
            titleDisplay.pause(1000);

            titleDisplay.setBackImage(new Location(0,0),"title5.png");
            titleDisplay.pause(1000);
            titleDisplay.dispose();
            runTitle=false;
        }
    }
    //that key code is passed to this method.
    private void keyPressed(int key){
        {   if(key==69){

                if(direction.equals("up")){
                    if(foreground[worldRow-1][worldCol]==20){
                        foreground[worldRow][worldCol]=28;
                        foreground[worldRow-1][worldCol]=22;
                        update();
                        display.pause(200);
                        foreground[worldRow][worldCol]=2;
                        foreground[worldRow-1][worldCol]=19;
                    }
                    else if(foreground[worldRow-1][worldCol]==19){
                        foreground[worldRow-1][worldCol]=2;
                        hasSword=true;
                    }
                    else if(hasSword==true&&foreground[worldRow-1][worldCol]==2){
                        foreground[worldRow-1][worldCol]=24;
                        foreground[worldRow][worldCol]=28;
                        update();
                        display.pause(200);
                        foreground[worldRow-1][worldCol]=2;
                        foreground[worldRow][worldCol]=2;
                    }
                    else if(hasSword==true&&foreground[worldRow-1][worldCol]==23||foreground[worldRow-1][worldCol]==32
                    ||foreground[worldRow-1][worldCol]==33||foreground[worldRow-1][worldCol]==34){
                        foreground[worldRow][worldCol]=28;
                        if(bossNum==1){
                            foreground[15][23]=38;
                            foreground[14][23]=36;
                            update();
                            display.pause(100);
                            foreground[15][23]=33;
                            foreground[14][23]=34;
                        }
                        else{
                            foreground[15][23]=37;
                            foreground[14][23]=35;
                            update();
                            display.pause(100);
                            foreground[15][23]=32;
                            foreground[14][23]=23;
                        }
                        foreground[worldRow][worldCol]=2;
                        bossHealth--;
                    }
                    else if(hasSword==true&&foreground[worldRow-1][worldCol]>=52&&foreground[worldRow-1][worldCol]<=58){
                        foreground[worldRow][worldCol]=28;
                        if(foreground[14][23]==53){
                            foreground[14][23]=73;
                        }
                        else{
                            foreground[14][23]=74;
                        }
                        foreground[13][22]=78;
                        foreground[13][24]=77;
                        foreground[13][23]=72;
                        foreground[15][22]=75;
                        foreground[15][24]=76;
                        update();
                        display.pause(100);
                        
                        if(foreground[14][23]==73){
                            foreground[14][23]=53;
                        }
                        else if(foreground[14][23]==74){
                            foreground[14][23]=54;
                        }
                        foreground[13][22]=58;
                        foreground[13][24]=57;
                        foreground[13][23]=52;
                        foreground[15][22]=55;
                        foreground[15][24]=56;
                         foreground[worldRow][worldCol]=2;
                          update();
                         bossHealth--;
                    }
                }
                else if(direction.equals("down")){
                    if(hasSword==true&&foreground[worldRow+1][worldCol]==2){
                        foreground[worldRow+1][worldCol]=26;
                        foreground[worldRow][worldCol]=30;
                        update();
                        display.pause(200);
                        foreground[worldRow+1][worldCol]=2;
                        foreground[worldRow][worldCol]=2;
                    }
                    else if(hasSword==true&&foreground[worldRow+1][worldCol]==23||foreground[worldRow+1][worldCol]==32
                    ||foreground[worldRow+1][worldCol]==33||foreground[worldRow+1][worldCol]==34){
                        foreground[worldRow][worldCol]=30;
                        if(bossNum==1){
                            foreground[15][23]=38;
                            foreground[14][23]=39;
                            update();
                            display.pause(100);
                            foreground[15][23]=33;
                            foreground[14][23]=34;
                        }
                        else{
                            foreground[15][23]=37;
                            foreground[14][23]=40;
                            update();
                            display.pause(100);
                            foreground[15][23]=32;
                            foreground[14][23]=23;
                        }
                        foreground[worldRow][worldCol]=2;
                        bossHealth--;
                    }
                    else if(hasSword==true&&foreground[worldRow+1][worldCol]>=52&&foreground[worldRow+1][worldCol]<=58){
                        foreground[worldRow][worldCol]=30;
                        if(foreground[14][23]==53){
                            foreground[14][23]=73;
                        }
                        else{
                            foreground[14][23]=74;
                        }
                        foreground[13][22]=78;
                        foreground[13][24]=77;
                        foreground[13][23]=72;
                        foreground[15][22]=75;
                        foreground[15][24]=76;
                        update();
                        display.pause(100);
                        
                        if(foreground[14][23]==73){
                            foreground[14][23]=53;
                        }
                        else if(foreground[14][23]==74){
                            foreground[14][23]=54;
                        }
                        foreground[13][22]=58;
                        foreground[13][24]=57;
                        foreground[13][23]=52;
                        foreground[15][22]=55;
                        foreground[15][24]=56;
                         bossHealth--;
                        foreground[worldRow][worldCol]=2;
                         update();
                    }
                }
                else if(direction.equals("left")){
                    if(hasSword==true&&foreground[worldRow][worldCol-1]==2){
                        foreground[worldRow][worldCol-1]=27;
                        foreground[worldRow][worldCol]=31;
                        update();
                        display.pause(200);
                        foreground[worldRow][worldCol-1]=2;
                        foreground[worldRow][worldCol]=2;
                    }
                    else if(hasSword==true&&(foreground[worldRow][worldCol-1]==23||foreground[worldRow][worldCol-1]==34)){
                        foreground[worldRow][worldCol]=31;
                        if(bossNum==1){
                            foreground[15][23]=38;
                            foreground[14][23]=42;
                            update();
                            display.pause(100);
                            foreground[15][23]=33;
                            foreground[14][23]=34;
                        }
                        else{
                            foreground[15][23]=37;
                            foreground[14][23]=44;
                            update();
                            display.pause(100);
                            foreground[15][23]=32;
                            foreground[14][23]=23;
                        }
                        foreground[worldRow][worldCol]=2;
                        bossHealth--;
                    }
                    else if(hasSword==true&&foreground[worldRow][worldCol-1]>=52&&foreground[worldRow][worldCol-1]<=58){
                        foreground[worldRow][worldCol]=31;
                        if(foreground[14][23]==53){
                            foreground[14][23]=73;
                        }
                        else{
                            foreground[14][23]=74;
                        }
                        foreground[13][22]=78;
                        foreground[13][24]=77;
                        foreground[13][23]=72;
                        foreground[15][22]=75;
                        foreground[15][24]=76;
                        update();
                        display.pause(100);
                       
                        if(foreground[14][23]==73){
                            foreground[14][23]=53;
                        }
                        else if(foreground[14][23]==74){
                            foreground[14][23]=54;
                        }
                        foreground[13][22]=58;
                        foreground[13][24]=57;
                        foreground[13][23]=52;
                        foreground[15][22]=55;
                        foreground[15][24]=56;
                         foreground[worldRow][worldCol]=2;
                          update();
                          bossHealth--;
                    }
                    else if(hasSword==true&&(foreground[worldRow][worldCol-1]==33||foreground[worldRow][worldCol-1]==32)){
                        foreground[worldRow][worldCol]=31;
                        if(bossNum==1){
                            foreground[15][23]=46;
                            foreground[14][23]=36;
                            update();
                            display.pause(100);
                            foreground[15][23]=33;
                            foreground[14][23]=34;
                        }
                        else{
                            foreground[15][23]=37;
                            foreground[14][23]=35;
                            update();
                            display.pause(100);
                            foreground[15][23]=32;
                            foreground[14][23]=23;
                        }
                        foreground[worldRow][worldCol]=2;
                        bossHealth--;
                    }
                }
                else if(hasSword==true&&foreground[worldRow][worldCol-1]>=52&&foreground[worldRow][worldCol-1]<=58){
                        foreground[worldRow][worldCol]=31;
                        if(foreground[14][23]==53){
                            foreground[14][23]=73;
                        }
                        else{
                            foreground[14][23]=74;
                        }
                        foreground[13][22]=78;
                        foreground[13][24]=77;
                        foreground[13][23]=72;
                        foreground[15][22]=75;
                        foreground[15][24]=76;
                        update();
                        display.pause(100);
                      
                        if(foreground[14][23]==73){
                            foreground[14][23]=53;
                        }
                        else if(foreground[14][23]==74){
                            foreground[14][23]=54;
                        }
                        foreground[13][22]=58;
                        foreground[13][24]=57;
                        foreground[13][23]=52;
                        foreground[15][22]=55;
                        foreground[15][24]=56;
                         foreground[worldRow][worldCol]=2;
                         update();
                          bossHealth--;
    
                    }
                else if(direction.equals("right")){
                    if(hasSword==true&&foreground[worldRow][worldCol+1]==2){
                        foreground[worldRow][worldCol+1]=25;
                        foreground[worldRow][worldCol]=29;
                        update();
                        display.pause(200);
                        foreground[worldRow][worldCol+1]=2;
                        foreground[worldRow][worldCol]=2;
                    }
                    else if(hasSword==true&&foreground[worldRow][worldCol+1]==23||foreground[worldRow][worldCol+1]==34
                    ){
                        foreground[worldRow][worldCol]=29;
                        if(bossNum==1){
                            foreground[15][23]=38;
                            foreground[14][23]=41;
                            update();
                            display.pause(100);
                            foreground[15][23]=33;
                            foreground[14][23]=34;
                        }
                        else{
                            foreground[15][23]=37;
                            foreground[14][23]=43;
                            update();
                            display.pause(100);
                            foreground[15][23]=32;
                            foreground[14][23]=23;
                        }
                        foreground[worldRow][worldCol]=2;
                        bossHealth--;
                    }
                    else if(hasSword==true&&foreground[worldRow][worldCol+1]>=52&&foreground[worldRow][worldCol+1]<=58){
                        foreground[worldRow][worldCol]=29;
                        if(foreground[14][23]==53){
                            foreground[14][23]=73;
                        }
                        else{
                            foreground[14][23]=74;
                        }
                        foreground[13][22]=78;
                        foreground[13][24]=77;
                        foreground[13][23]=72;
                        foreground[15][22]=75;
                        foreground[15][24]=76;
                        update();
                        display.pause(100);
                        bossHealth--;
                        if(foreground[14][23]==73){
                            foreground[14][23]=53;
                        }
                        else if(foreground[14][23]==74){
                            foreground[14][23]=54;
                        }
                        foreground[13][22]=58;
                        foreground[13][24]=57;
                        foreground[13][23]=52;
                        foreground[15][22]=55;
                        foreground[15][24]=56;
                         update();
                         foreground[worldRow][worldCol]=2;
                    }
                    else if(hasSword==true&&(foreground[worldRow][worldCol+1]==33||foreground[worldRow][worldCol+1]==32)){
                        foreground[worldRow][worldCol]=29;
                        if(bossNum==1){
                            foreground[15][23]=38;
                            foreground[14][23]=36;
                            update();
                            display.pause(100);
                            foreground[15][23]=33;
                            foreground[14][23]=34;
                        }
                        else{
                            foreground[15][23]=45;
                            foreground[14][23]=35;
                            update();
                            display.pause(100);
                            foreground[15][23]=32;
                            foreground[14][23]=23;
                        }
                        foreground[worldRow][worldCol]=2;
                        bossHealth--;
                    }
                }

            }
            else if(key==87){
                direction="up";
                if(foreground[worldRow-1][worldCol]==2){
                    worldRow--;
                }
                else if(foreground[worldRow-1][worldCol]==21){
                    foreground[worldRow-1][worldCol]=2;
                    worldRow--;
                    if(health<3){
                        health++; 
                    }
                }
                else if(foreground[worldRow-1][worldCol]==48||foreground[worldRow-1][worldCol]==47){
                    worldRow--;
                    foreground[worldRow][worldCol]=69;
                    update();
                    display.pause(100);
                    health--;
                    foreground[worldRow][worldCol]=2;
                }
                else if(foreground[worldRow-1][worldCol]==70||foreground[worldRow-1][worldCol]==71){
                    worldRow--;
                    foreground[worldRow][worldCol]=69;
                    update();
                    display.pause(100);
                    health-=2;
                    foreground[worldRow][worldCol]=2;
                }
            }
            else if(key==83){
                direction="down";
                if(foreground[worldRow+1][worldCol]==2){
                    worldRow++;
                }
                else if(foreground[worldRow+1][worldCol]==21){
                    foreground[worldRow+1][worldCol]=2;
                    worldRow++;
                    if(health<3){
                        health++; 
                    }
                }
                else if(foreground[worldRow+1][worldCol]==47||foreground[worldRow+1][worldCol]==48){
                    worldRow++;
                    foreground[worldRow][worldCol]=51;
                    update();
                    display.pause(100);
                    health--;
                    foreground[worldRow][worldCol]=2;
                }
                else if(foreground[worldRow+1][worldCol]==70||foreground[worldRow+1][worldCol]==71){
                    worldRow++;
                    foreground[worldRow][worldCol]=51;
                    update();
                    display.pause(100);
                    health-=2;
                    foreground[worldRow][worldCol]=2;
                }
            }
            else if(key==65){
                direction="left";
                if(foreground[worldRow][worldCol-1]==2){
                    worldCol--;
                }
                else if(foreground[worldRow][worldCol-1]==21){
                    foreground[worldRow][worldCol-1]=2;
                    worldCol--;
                    if(health<3){
                        health++; 
                    }
                }
                else if(foreground[worldRow][worldCol-1]==47||foreground[worldRow][worldCol-1]==48){
                    worldCol--;
                    foreground[worldRow][worldCol]=50;
                    update();
                    display.pause(100);
                    health--;
                    foreground[worldRow][worldCol]=2;
                }
                else if(foreground[worldRow][worldCol-1]==70||foreground[worldRow][worldCol-1]==71){
                    worldCol--;
                    foreground[worldRow][worldCol]=50;
                    update();
                    display.pause(100);
                    health-=2;
                    foreground[worldRow][worldCol]=2;
                }
            }
            else if(key==68){
                direction="right";
                if(foreground[worldRow][worldCol+1]==2){
                    worldCol++;
                }
                else if(foreground[worldRow][worldCol+1]==21){
                    foreground[worldRow][worldCol+1]=2;
                    worldCol++;
                    if(health<3){
                        health++; 
                    }
                }
                else if(foreground[worldRow][worldCol+1]==47||foreground[worldRow][worldCol+1]==48){
                    worldCol++;
                    foreground[worldRow][worldCol]=49;
                    update();
                    display.pause(100);
                    health--;
                    foreground[worldRow][worldCol]=2;
                }
                 else if(foreground[worldRow][worldCol+1]==70||foreground[worldRow][worldCol+1]==71){
                    worldCol++;
                    foreground[worldRow][worldCol]=49;
                    update();
                    display.pause(100);
                    health-=2;
                    foreground[worldRow][worldCol]=2;
                }
            }
            counter++;
        }
    }
    //this method is called at regular intervals
    public void step()
    {
        if(counter>=1){
            counter=0;
            if(num==1){
                num=2;
            }
            else{
                num=1;
            }
        }
        if(bossCounter>=5){
            bossCounter=0;
            if(bossNum==1){
                bossNum=2;
            }
            else{
                bossNum=1;
            }
        }
        if(finalForm==false){
  updateFireAndWarningSequential(800, new int[]{15, 14, 13, 14, 15, 16},new int[]{22, 22, 23, 24, 24, 23});
}


        
        else if(finalForm == true){
          updateRedFirePulse(800, new int[]{14,13,12,12,12,13,14,15,16,16,15,15},new int[]{22,21,22,23,24,25,24,25,24,22,21,23});
        }


            
            
        

        if(bossNum==1){
            foreground[14][23]=53;

        }
        else{
            foreground[14][23]=54;

        }

        if(!finalForm){
            if(bossNum==1){
                foreground[15][23]=33;
                foreground[14][23]=34;
            }
            else{
                foreground[15][23]=32;
                foreground[14][23]=23;
            }
        }
        if(direction.equals("right")){
            if(num==1){
                display.setForeImage(heroLoc,"RightS.png");
            }
            else{
                display.setForeImage(heroLoc,"RightW.png");
            }
        }
        else if(direction.equals("left")){
            if(num==1){
                display.setForeImage(heroLoc,"LeftS.png");
            }
            else{
                display.setForeImage(heroLoc,"LeftW.png");
            }
        }
        else if(direction.equals("up")){
            if(num==1){
                display.setForeImage(heroLoc,"BackL.png");
            }
            else{
                display.setForeImage(heroLoc,"BackR.png");
            }
        }
        else if(direction.equals("down")){
            if(num==1){
                display.setForeImage(heroLoc,"StraightL.png"); 
            }
            else{
                display.setForeImage(heroLoc,"StraightR.png");
            }
        }
        if(bossHealth==25){
            worldRow=14;
            worldCol=20;
            bossHealth--;
            foreground[14][23]=53;
            foreground[13][22]=58;
            foreground[13][24]=57;
            foreground[13][23]=52;
            foreground[15][22]=55;
            foreground[15][24]=56;
            foreground[15][23]=2;
            finalForm=true;
        }
        if(bossHealth<=1){

            foreground[14][23]=53;
            foreground[13][22]=58;
            foreground[13][24]=57;
            foreground[13][23]=52;
            foreground[15][22]=55;
            foreground[15][24]=56;
            foreground[15][23]=2;
            
            finalForm=true;
        }
        if(health<=0){
            display.dispose();
            GridDisplay endDisplay=new GridDisplay(1,1);
            endDisplay.setBackImage(new Location(0,0),"gameOver2.png");
            endDisplay.pause(800);
            endDisplay.setBackImage(new Location(0,0),"gameOver3.png");
            endDisplay.pause(800);
            endDisplay.setBackImage(new Location(0,0),"gameOver4.png");
            endDisplay.pause(800);
            endDisplay.setBackImage(new Location(0,0),"gameOver1.png");
            endDisplay.pause(1000);
            endDisplay.dispose();
            System.exit(0);
        }
        if (bossHealth <= 1) {
    display.dispose();  

    GridDisplay endDisplay = new GridDisplay(1, 1);
    endDisplay.setBackImage(new Location(0, 0), "win.png");  
    endDisplay.pause(2000); 
    endDisplay.dispose();
    System.exit(0);  
}

    }

    //this code starts a game when you click the run button
    public static void main(String[] args)
    {
        Game g = new Game();
        g.play();
    }

    private boolean isBossTile(int row, int col) {
        return (row == 14 && col == 23) ||  // torso
        (row == 13 && col == 22) ||  // left arm
        (row == 13 && col == 23) ||  // left arm center
        (row == 13 && col == 24) ||  // right arm
        (row == 15 && col == 22) ||  // left leg
        (row == 15 && col == 23) ||  // bottom center leg
        (row == 15 && col == 24);    // right leg
    }
  // Call this once per step to maybe spawn fire somewhere
// Class variables to track state
int fireRow = -1;
int fireCol = -1;
  
boolean fireActive = false;
long fireStartTime = 0;
int[] fireRows;
int[] fireCols;// example cols near boss (adjust as needed)
int fireIndex = 0;
public void updateFireAndWarningSequential(int time,int[] row,int[] col) {
    fireRows=row;
    fireCols=col;
    long now = System.currentTimeMillis();
  final long FIRE_DURATION = time; 
    if (!warningActive && !fireActive) {
        // Try next position in sequence
        int r = fireRows[fireIndex];
        int c = fireCols[fireIndex];
        int tile = foreground[r][c];
        // Only pick if tile is valid (not boss or empty or exclamation or fire)
        if (tile != 23 && tile != 0 && tile != 64 && tile != 47 && tile!=32) {
            fireRow = r;
            fireCol = c;

            warningActive = true;
            warningStartTime = now;
        }

        // Advance to next index for next cycle
        fireIndex = (fireIndex + 1) % fireRows.length;
    }

    if (warningActive) {
        // Show exclamation point above fire location if player is on the same tile
        if (worldRow == fireRow && worldCol == fireCol) {
            foreground[fireRow - 1][fireCol] = 64; // exclamation point
        } else {
            // Player moved off danger tile before fire appears
            if (foreground[fireRow - 1][fireCol] == 64) {
                foreground[fireRow - 1][fireCol] = 2; // clear exclamation
            }
            if (!fireActive) {
                warningActive = false;
                fireActive = true;
                fireStartTime = now;
                foreground[fireRow][fireCol] = 47; // fire tile
            }
        }

        // Time's up for warning, spawn fire
        if (now - warningStartTime >= WARNING_DURATION) {
            warningActive = false;
            if (foreground[fireRow - 1][fireCol] == 64) {
                foreground[fireRow - 1][fireCol] = 2; // clear exclamation
            }
            fireActive = true;
            fireStartTime = now;
            foreground[fireRow][fireCol] = 47; // fire tile

            // Damage player if on fire tile
            if (worldRow == fireRow && worldCol == fireCol) {
                health--;

                // Show on-fire animation based on direction
                switch (direction) {
                    case "right": foreground[worldRow][worldCol] = 49; break;
                    case "left": foreground[worldRow][worldCol] = 50; break;
                    case "down": foreground[worldRow][worldCol] = 51; break;
                    case "up": foreground[worldRow][worldCol] = 69; break;
                    default: foreground[worldRow][worldCol] = 47; break;
                }
                update();
                display.pause(70);
                foreground[worldRow][worldCol] = 2;
            }
        }
    }

    if (fireActive) {
        // Animate fire flicker
        if ((now / 300) % 2 == 0) {
            foreground[fireRow][fireCol] = 47;
        } else {
            foreground[fireRow][fireCol] = 48;
        }

        // Remove fire after fire duration
        if (now - fireStartTime >= FIRE_DURATION) {
            foreground[fireRow][fireCol] = 2;
            fireActive = false;
            fireRow = -1;
            fireCol = -1;
        }
    }
}

// Store original tiles above warning positions


// Phase 0 = idle, 1 = gap, 2 = exclamation, 3 = fire
int redFirePhase = 0;
long redFireTimer = 0;

public void updateRedFirePulse(int time, int[] fireRows, int[] fireCols) {
    long now = System.currentTimeMillis();
    final long FIRE_DURATION = time;
    final long GAP_DURATION = 400;         // delay before exclamations
    final long WARNING_DURATION = 700;     // exclamation duration

    // Fixed positions for exclamation points
    int[] exclamRows = {12, 12, 12};
    int[] exclamCols = {22, 23, 24};

    if (fireRows.length != fireCols.length) return;

    switch (redFirePhase) {
        case 0: // Idle
            redFirePhase = 1;
            redFireTimer = now;
            break;

        case 1: // Gap phase (nothing shown)
            if (now - redFireTimer >= GAP_DURATION) {
                redFirePhase = 2;
                redFireTimer = now;
            }
            break;

        case 2: // Exclamation warning at fixed positions only
            for (int i = 0; i < exclamRows.length; i++) {
                int r = exclamRows[i];
                int c = exclamCols[i];
                if (foreground[r][c] == 2) {  // only replace empty tiles
                    foreground[r][c] = 64;     // exclamation point
                }
            }

            if (now - redFireTimer >= WARNING_DURATION) {
                // Clear exclamation points
                for (int i = 0; i < exclamRows.length; i++) {
                    int r = exclamRows[i];
                    int c = exclamCols[i];
                    if (foreground[r][c] == 64) {
                        foreground[r][c] = 2;
                    }
                }

                redFirePhase = 3;
                redFireTimer = now;
            }
            break;

        case 3: // Fire phase at original positions
            boolean showFirstFrame = (now / 300) % 2 == 0;

            for (int i = 0; i < fireRows.length; i++) {
                int r = fireRows[i];
                int c = fireCols[i];

                if (worldRow != r || worldCol != c) {
                    foreground[r][c] = showFirstFrame ? 70 : 71;
                }

                if (worldRow == r && worldCol == c && showFirstFrame) {
                    health -= 2;

                    switch (direction) {
                        case "right": foreground[worldRow][worldCol] = 49; break;
                        case "left":  foreground[worldRow][worldCol] = 50; break;
                        case "down":  foreground[worldRow][worldCol] = 51; break;
                        case "up":    foreground[worldRow][worldCol] = 69; break;
                        default:      foreground[worldRow][worldCol] = 70; break;
                    }

                    update();
                    display.pause(70);
                    foreground[worldRow][worldCol] = 2;
                }
            }

            if (now - redFireTimer >= FIRE_DURATION) {
                for (int i = 0; i < fireRows.length; i++) {
                    foreground[fireRows[i]][fireCols[i]] = 2;
                }
                redFirePhase = 0; // reset to idle
            }
            break;
    }
}




}






