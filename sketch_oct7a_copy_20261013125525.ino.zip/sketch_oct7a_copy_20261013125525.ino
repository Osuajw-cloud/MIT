#include <Servo.h>



Servo RM;
Servo LM;

void setup() {
  // put your setup code here, to run once:
LM.attach(9);
RM.attach(10);
}

void loop() {
  // put your main code here, to run repeatedly:
  for(int x=0;x<){

  }
RM.write(82);
LM.write(100);
delay(3300);
RM.write(50);
LM.write(90);
delay(800);
RM.write(90);
LM.write(90);
delay(1000);
RM.write(82);
LM.write(100);
delay(3200);
RM.write(90);
LM.write(130);
delay(820);
RM.write(82);
LM.write(100);
delay(650);
RM.write(90);
LM.write(110);
delay(1200);
RM.write(82);
LM.write(100);
delay(6200);
RM.write(50);
LM.write(90);
delay(1200);
RM.write(82);
LM.write(100);
delay(4500);
RM.write(50);
LM.write(90);
delay(200);
RM.write(82);
LM.write(100);
delay(1200);
RM.write(90);
LM.write(90);
delay(5500);

}
